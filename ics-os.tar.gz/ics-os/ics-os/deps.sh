#!/bin/bash
sudo apt-get update
sudo apt-get install qemu-kvm git tcc nasm build-essential git gcc-multilib 
