const char *get_function_name (int deviceid,int func_num);
