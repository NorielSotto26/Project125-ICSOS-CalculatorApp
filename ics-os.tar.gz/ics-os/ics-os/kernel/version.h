#ifndef __VERSION_H_
#define __VERSION_H_

#define KERNEL_VERSION "0.01"
#define KERNEL_NAME    "vmdex"

#define OS_NAME        "ICS Operating System"
#define OS_VERSION     "0.01"


char *dex32_versionstring=OS_NAME;


#endif
