#define ARCH_I386
#define OS_LINUX
#define HAVE_PM_LINUX_PROC
#define HAVE_LINUX_BYTEORDER_H
#define PATH_PROC_BUS_PCI "/proc/bus/pci"
#define HAVE_PM_INTEL_CONF
#define HAVE_PM_DUMP
#define PATH_PCI_IDS "--help/pci.ids"
#define PCILIB_VERSION "0.0"
