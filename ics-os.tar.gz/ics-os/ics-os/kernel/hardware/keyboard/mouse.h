
sync_sharedvar mouse_busywait;
unsigned char mouse_read();
void installmouse();
