/*
  Name: script.c
  Copyright: 
  Author: Joseph Emmanuel DL Dayo
  Date: 20/01/04 04:51
  Description: An exteremely simple shell script interpreter
*/
#define SCRIPT_MAXINSTANCE 20

int script_load(const char *filename);
