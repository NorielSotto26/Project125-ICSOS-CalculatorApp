
#include "../../sdk/dexsdk.h"

int main() 
{
   printf("Hello World from ICS-OS!\n");
   printf("Doing division by zero!");
   printf("%f",100.0/0);
   return 0;
}
